﻿class IndexedDBInstance {
    #DBName;
    #DBVersion;
    DBStatus;
    #db;

    constructor(dbName, dbVersion) {
        this.#DBName = dbName;
        this.#DBVersion = dbVersion;
        this.DBStatus = false;
        this.#db = null;
    }

    async initLocalForage() {
        localforage.config({
            driver: [localforage.INDEXEDDB],
            name: this.#DBName,
            storeName: 'RecordBlobs',
            version: this.#DBVersion,
            description: 'For store blobs'
        });
        if (!localforage.supports(localforage.INDEXEDDB)) {
            throw new Error('当前浏览器不支持 IndexedDB，无法创建存储对象');
        }
        await localforage.ready().then(() => {
            // 数据库已经准备好
            this.DBStatus = true;
        }).catch(function (err) {
            throw new Error('IndexedDB初始化异常！');
        });
    }
    
    async setItemInDB(key, blobs, successCallback) {
        if (!this.DBStatus) {
            throw new Error('IndexedDB未初始化！');
        }
        let keyID = nanoid(10);
        localforage.setItem(keyID, [Date.now(), blobs]).then(function (value) {
            console.log(value);
        }).catch(function (err) {
            throw new Error('IndexedDB 功能异常（如隐私模式禁用）');
        });
    }
    
    async getItemFromDB(key, successCallback) {
        
    }

    // async getBlobById(id) {
    //     if (!this.#db || this.#db.close) await this.#openDB();
    //
    //     return new Promise((resolve, reject) => {
    //         const transaction = this.#db.transaction(['blobs'], 'readonly');
    //         const store = transaction.objectStore('blobs');
    //
    //         const request = store.get(id);
    //
    //         request.onsuccess = () => {
    //             if (request.result) {
    //                 resolve(request.result.blob);
    //             } else {
    //                 reject('未找到对应数据');
    //             }
    //         };
    //         request.onerror = (e) => reject('读取失败: ' + e.target.error);
    //     });
    // }
    //
    // async deleteBlob(id) {
    //     if (!this.#db || this.#db.close) await this.#openDB();
    //
    //     return new Promise((resolve, reject) => {
    //         const transaction = this.#db.transaction(['blobs'], 'readwrite');
    //         const store = transaction.objectStore('blobs');
    //
    //         const request = store.delete(id);
    //
    //         request.onsuccess = () => resolve();
    //         request.onerror = (e) => reject('删除失败: ' + e.target.error);
    //     });
    // }

// 删除7天前的数据
    async #cleanupOldBlobs(days = 7) {
        const threshold = Date.now() - days * 86400000;
        const transaction = this.#db.transaction(['blobs'], 'readwrite');
        const store = transaction.objectStore('blobs');
        const request = store.openCursor();

        request.onsuccess = (e) => {
            const cursor = e.target.result;
            if (cursor) {
                if (cursor.value.timestamp < threshold) {
                    cursor.delete();
                }
                cursor.continue();
            }
        };
    }
}